//
//  SecondViewController.m
//  Table
//
//  Created by hipiao on 2017/1/10.
//  Copyright © 2017年 James. All rights reserved.
//

#import "SecondViewController.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor yellowColor];
    
    [self createSubViews];
}
-(void)createSubViews{

    UILabel * lb = [[UILabel alloc]initWithFrame:CGRectMake(0, 100, 200, 60)];
    lb.backgroundColor = [UIColor redColor];
    [self.view addSubview:lb];

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
