//
//  FireView.h
//  Table
//
//  Created by hipiao on 2017/2/6.
//  Copyright © 2017年 James. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface FireView : UIView

@property (nonatomic, strong)NSString *gifUrlStr;

@property (nonatomic, strong)UIView *bgAllView;
@property (nonatomic, strong)UIImageView *gifImageView;
@property (nonatomic, strong)UILabel *labCharmValue;   //魅力值 +20 !
@property (nonatomic, strong)UILabel *labName;
@property (nonatomic, strong)UIButton *btnFlowerLanguage; //花语
@property (nonatomic, strong)UIImageView  *bgImageView;
@property (nonatomic, strong)UIButton *btnDismiss;
@property (nonatomic, strong)UIButton *btnStart;


+(instancetype)sharedDefaultAnimationView;
-(void)show;
-(void)hiden;


@end
