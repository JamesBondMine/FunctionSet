//
//  TicketsCodeModel.h
//  OscarFilm
//
//  Created by hipiao on 2016/12/3.
//  Copyright © 2016年 VCFilm. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TicketsCodeModel : NSObject

/**
 *----生成二维码------
 *
 */
+(UIImage *)createNonInterpolatedUIImageFormCIImage:(CIImage *)image withSize:(CGFloat) size;


/**
 *----生成条形码------
 *
 */
+(UIImage*)generateBarCode:(NSString*)barCodeStr width:(CGFloat)width height:(CGFloat)height;

@end
