//
//  SucceedView.h
//  hipiaonew
//
//  Created by OceanSea on 16/4/15.
//  Copyright © 2016年 dadi. All rights reserved.
//

#import <UIKit/UIKit.h>

static NSInteger const kButtonTag = 51406102;

@class TicketCodeModel;

@interface SucceedView : UIView

@property (nonatomic, strong) UIButton * checkButton;

@property (nonatomic, strong) UIButton * btnCheckOrder;

@property (nonatomic, strong) UIScrollView  * bgScrollView;

@property (nonatomic, strong) TicketCodeModel * codeModel;

- (void)operateResult:(id)target action:(SEL)action;

- (void)gestureTap:(id)target action:(SEL)action;

- (void)checkPrize:(id)target action:(SEL)action;

- (void)refreshState;
@end
