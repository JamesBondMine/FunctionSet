//
//  MasonryViewController.m
//  Table
//
//  Created by hipiao on 2016/12/12.
//  Copyright © 2016年 James. All rights reserved.
//

#import "MasonryViewController.h"
#import "TicketsViewController.h"
#import "SearchViewController.h"
#import "TestCell.h"
#import "TestModel.h"


@interface MasonryViewController ()<UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) UITableView    * tableView;
@property (nonatomic, strong) NSMutableArray * dataSource;
@property (nonatomic, strong) NSMutableArray * typeSource;

@property (nonatomic, strong) UIButton * btnBack;
@property (nonatomic, strong) UIButton * btnOther;


@end

@implementation MasonryViewController

-(void)btnAction:(UIButton *)sender{

    if (sender.tag == 1001) {
        [self dismissViewControllerAnimated:YES completion:nil];
    }else{
        TicketsViewController * tickets = [[TicketsViewController alloc]init];
        [self presentViewController:tickets animated:YES completion:nil];
    }
}
- (void)returnText:(ReturnTextBlock)block {
    self.returnTextBlock = block;
}
- (void)viewWillDisappear:(BOOL)animated {
    
    if (self.returnTextBlock != nil) {
        self.returnTextBlock(@"我是一个快乐的block");
    }
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.btnBack = [UIButton buttonWithType:UIButtonTypeCustom];
    self.btnBack.frame = CGRectMake(0, 0, Screenwidth/2, 64);
    self.btnBack.backgroundColor = [UIColor redColor];
    [self.btnBack setTitle:@"返回" forState:UIControlStateNormal];
    [self.btnBack addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.btnBack];
    self.btnBack.tag = 1001;
    
    
    self.btnOther = [UIButton buttonWithType:UIButtonTypeCustom];
    self.btnOther.frame = CGRectMake(Screenwidth/2, 0, Screenwidth/2, 64);
    self.btnOther.backgroundColor = [UIColor greenColor];
    [self.btnOther setTitle:@"取票" forState:UIControlStateNormal];
    [self.btnOther addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.btnOther];
    self.btnOther.tag = 1002;
    
    
    
    
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 74, Screenwidth,ScreenHeight-74) style:UITableViewStyleGrouped];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.backgroundColor = [[UIColor lightGrayColor]colorWithAlphaComponent:0.3];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
    

    [self requestModel];
    
    
    for (NSUInteger i = 0; i < 10; ++i) {
        [self.typeSource addObject:@"0"];
        TestModel *model = [[TestModel alloc] init];
        if (i<3) {
            model.title = @"测试标题，可能很长很长，反正随便写着先吧！";
            model.desc = @"描述内容通常都是很长很长的，";
        }else{
            model.title = @"测试标题，可能很长很长，反正随便写着先吧！";
            model.desc = @"描述内容通常都是很长很长的，描述内容通常都是很长很长的，描述内容通常都是很长很长的，描述内容通常都是很长很长的，描述内容通常都是很长很长的，描述内容通常都是很长很长的，描述内容通常都是很长很长的，描述内容通常都是很长很长的，描述内容通常都是很长很长的，描述内容通常都是很长很长的，描述内容通常都是很长很长的，";
        }
        [self.dataSource addObject:model];
    }
    [self.tableView reloadData];
    
}
-(void)requestModel{

    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    NSDictionary * parameters = @{@"token": @"",
                                 @"cityId":@"110100",
                                 @"pageSize":@"30",
                                 @"pageNo":@"1",
                                 @"platform":@"5",
                                 @"filmId":@"6751",
                                 @"token":@"a3e78fbef9103c6272ebd28c3fe70709"};
    
    [manager setSecurityPolicy:[self customSecurityPolicy:@"ca_bundle"]];
    [manager POST:@"https://open.vcdianying.cn/review/queryReviewAndTag" parameters:parameters
          progress:nil success:^(NSURLSessionDataTask * operation, id responseObject) {
       
              NSLog(@"%@", responseObject);
        
          } failure:^(NSURLSessionDataTask * operation, NSError *error) {
        
              NSLog(@"Error: %@", error);
    
          }];
}
-(AFSecurityPolicy *)customSecurityPolicy:(NSString *)certificate
{
    // /先导入证书
    NSString * cerPath = [[NSBundle mainBundle] pathForResource:certificate ofType:@"cer"];//证书的路径
    NSData * certData = [NSData dataWithContentsOfFile:cerPath];
    
    // AFSSLPinningModeCertificate 使用证书验证模式
    AFSecurityPolicy * securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeCertificate];
    
    // allowInvalidCertificates 是否允许无效证书（也就是自建的证书），默认为NO
    // 如果是需要验证自建证书，需要设置为YES
    securityPolicy.allowInvalidCertificates = YES;
    
    //validatesDomainName 是否需要验证域名，默认为YES；
    //假如证书的域名与你请求的域名不一致，需把该项设置为NO；如设成NO的话，即服务器使用其他可信任机构颁发的证书，也可以建立连接，这个非常危险，建议打开。
    //置为NO，主要用于这种情况：客户端请求的是子域名，而证书上的是另外一个域名。因为SSL证书上的域名是独立的，假如证书上注册的域名是www.google.com，那么mail.google.com是无法验证通过的；当然，有钱可以注册通配符的域名*.google.com，但这个还是比较贵的。
    //如置为NO，建议自己添加对应域名的校验逻辑。
    securityPolicy.validatesDomainName = NO;
    securityPolicy.pinnedCertificates = [NSSet setWithArray:@[certData]];
    
    return securityPolicy;
}

- (NSMutableArray *)dataSource {
    if (_dataSource == nil) {
        _dataSource = [[NSMutableArray alloc] init];
    }
    
    return _dataSource;
}
- (NSMutableArray *)typeSource {
    if (_typeSource == nil) {
        _typeSource = [[NSMutableArray alloc] init];
    }
    
    return _typeSource;
}
#pragma mark - UITableViewDataSource
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.dataSource.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    
    return 1;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString * cellIdentifier = @"cell";
    TestCell * cell = [tableView cellForRowAtIndexPath:indexPath];
    if (cell == nil) {
        cell = [[TestCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleBlue;
    TestModel * model = [self.dataSource objectAtIndex:indexPath.section];
    [cell configCellWithModel:model cellType:[[self.typeSource objectAtIndex:indexPath.section] intValue]];
    cell.btnMore.tag = indexPath.section;
    [cell.btnMore addTarget:self action:@selector(moreDetailAction:) forControlEvents:UIControlEventTouchUpInside];
    
    return cell;
}
-(void)moreDetailAction:(UIButton *)sender{

    if ([[self.typeSource objectAtIndex:sender.tag] intValue] == 0) {
        [self.typeSource replaceObjectAtIndex:sender.tag withObject:@"1"];
    }else{
        [self.typeSource replaceObjectAtIndex:sender.tag withObject:@"0"];
    }
    [self.tableView reloadData];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    TestModel * model = [self.dataSource objectAtIndex:indexPath.section];
    return [TestCell heightWithModel:model cellType:[[self.typeSource objectAtIndex:indexPath.section] intValue]]+10;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
