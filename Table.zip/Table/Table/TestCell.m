//
//  TestCell.m
//  Table
//
//  Created by hipiao on 2016/12/12.
//  Copyright © 2016年 James. All rights reserved.
//

#import "TestCell.h"

@implementation TestCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self){
        [self setSelectionStyle:UITableViewCellSelectionStyleNone];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        [self setLocation];
        
    }
    return self;
}
-(void)setLocation{
    
    [self addSubview:self.mainLabel];
    [self addSubview:self.descLabel];
    [self addSubview:self.btnMore];
    [self addSubview:self.filmDetail];
}
- (void)configCellWithModel:(TestModel *)model cellType:(int)cellType{

    self.mainLabel.text = model.title;
    self.descLabel.text = model.desc;
    
    __weak typeof(self)weakself = self;
    [self.mainLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(weakself.contentView.mas_left).offset(15);
        make.right.mas_equalTo(weakself.contentView.mas_right).offset(-15);
        make.top.mas_equalTo(weakself.contentView.mas_top).offset(15);
    }];
    
    [self.descLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(weakself.contentView.mas_left).offset(15);
        make.right.mas_equalTo(weakself.contentView.mas_right).offset(-15);
        make.top.mas_equalTo(weakself.mainLabel.mas_bottom).offset(15);
        make.width.mas_equalTo(Screenwidth-30);
    }];
    
    [self.btnMore mas_updateConstraints:^(MASConstraintMaker * make) {
        make.left.mas_equalTo(weakself.contentView.mas_left).offset(15);
        make.right.mas_equalTo(weakself.contentView.mas_right).offset(-15);
        make.top.mas_equalTo(weakself.descLabel.mas_bottom).offset(10);
        make.height.mas_equalTo(@30);
    }];
    [self.filmDetail mas_updateConstraints:^(MASConstraintMaker * make) {
        make.left.mas_equalTo(weakself.contentView.mas_left).offset(15);
        make.right.mas_equalTo(weakself.contentView.mas_right).offset(-15);
        make.top.mas_equalTo(weakself.btnMore.mas_bottom);
        make.height.mas_equalTo(60*cellType);
    }];
    
}
+ (CGFloat)heightWithModel:(TestModel *)model cellType:(int )cellType{
    TestCell *cell = [[TestCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@""];
    [cell configCellWithModel:model cellType:cellType];
    [cell layoutIfNeeded];
    CGRect frame =  cell.filmDetail.frame;
    return frame.origin.y + frame.size.height + 10;
}
- (UILabel *)mainLabel
{
    if (!_mainLabel) {
        _mainLabel = [UILabel new];
        _mainLabel.text = @"支付剩余时间：10:22";
        _mainLabel.numberOfLines = 0;
    }
    return _mainLabel;
}
- (UILabel *)descLabel
{
    if (!_descLabel) {
        _descLabel = [UILabel new];
        _descLabel.numberOfLines = 0;
        _descLabel.textColor = [UIColor lightGrayColor];
        _descLabel.font = [UIFont systemFontOfSize:14];
    }
    return _descLabel;
}
- (UILabel *)filmDetail
{
    if (!_filmDetail) {
        _filmDetail = [UILabel new];
        _filmDetail.numberOfLines = 0;
        _filmDetail.backgroundColor = [UIColor yellowColor];
        _filmDetail.font = [UIFont systemFontOfSize:14];
    }
    return _filmDetail;
}
- (UIButton *)btnMore
{
    if (!_btnMore) {
        _btnMore = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnMore setTitle:@"按下去" forState:UIControlStateNormal];
        _btnMore.backgroundColor = [UIColor redColor];
    }
    return _btnMore;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
