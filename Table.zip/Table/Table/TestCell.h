//
//  TestCell.h
//  Table
//
//  Created by hipiao on 2016/12/12.
//  Copyright © 2016年 James. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "TestModel.h"


typedef void (^TestBlock)(NSIndexPath * indexPath);

@interface TestCell : UITableViewCell
@property (nonatomic, strong) UILabel *mainLabel;
@property (nonatomic, strong) UILabel *descLabel;
@property (nonatomic, strong) UILabel *filmDetail;

@property (nonatomic, strong) UIButton *button;

@property (nonatomic, assign) BOOL isExpandedNow;



@property (nonatomic, strong) UIButton * btnMore;


@property (nonatomic, strong) UILabel * titleLabel;
@property (nonatomic, strong) NSIndexPath *indexPath;

@property (nonatomic, copy) TestBlock block;

- (void)configCellWithModel:(TestModel *)model cellType:(int )cellType;

+ (CGFloat)heightWithModel:(TestModel *)model cellType:(int )cellType;


@end
