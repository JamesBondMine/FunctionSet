//
//  TicketsViewController.m
//  Table
//
//  Created by hipiao on 2016/12/12.
//  Copyright © 2016年 James. All rights reserved.
//

#import "TicketsViewController.h"
#import "SucceedView.h"

#import "SearchViewController.h"

#import "XIBViewController.h"
@interface TicketsViewController ()

@property (nonatomic,strong) SucceedView * succeView;
@end

@implementation TicketsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.succeView = [[SucceedView alloc]initWithFrame:self.view.bounds];
    [self.view addSubview:self.succeView];
    [self.succeView.btnCheckOrder addTarget:self action:@selector(antherView) forControlEvents:UIControlEventTouchUpInside];
    
    SearchViewController * viewController = [[SearchViewController alloc] init];
    [self addChildViewController:viewController];
}
-(void)antherView{

    SearchViewController * anther = [[SearchViewController alloc]init];
    UINavigationController * nav = [[UINavigationController alloc]initWithRootViewController:anther];
    [nav.navigationBar setBackgroundImage:[UIImage imageNamed:@"navbar"] forBarMetrics:UIBarMetricsDefault];
    nav.navigationBar.titleTextAttributes=@{NSForegroundColorAttributeName:[UIColor whiteColor]};
    [nav.navigationBar setBackgroundColor:[UIColor blackColor]];
    [self presentViewController:nav animated:YES completion:nil];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

/*
#pragma mark - Navigation
// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
