//
//  TestModel.h
//  Table
//
//  Created by hipiao on 2016/12/12.
//  Copyright © 2016年 James. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TestModel : NSObject

@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *desc;

@property (nonatomic, assign) int uid;
@property (nonatomic, assign) BOOL isExpand;

@end
