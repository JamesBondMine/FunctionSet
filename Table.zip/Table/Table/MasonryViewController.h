//
//  MasonryViewController.h
//  Table
//
//  Created by hipiao on 2016/12/12.
//  Copyright © 2016年 James. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^ReturnTextBlock)(NSString *showText);

@interface MasonryViewController : UIViewController



@property (nonatomic, copy) ReturnTextBlock returnTextBlock;

- (void)returnText:(ReturnTextBlock)block;

@end
