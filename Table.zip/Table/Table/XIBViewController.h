//
//  XIBViewController.h
//  Table
//
//  Created by hipiao on 2016/12/23.
//  Copyright © 2016年 James. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XIBViewController : UIViewController

@end
